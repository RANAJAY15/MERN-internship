const Home=()=>{
    return(
        <div>
        <h1>Welcome to home page</h1>
        </div>
    )
}
export default Home