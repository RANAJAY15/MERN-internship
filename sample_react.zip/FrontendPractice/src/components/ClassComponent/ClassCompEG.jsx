import React from 'react';
class ClassCompEg extends React.Component {
    //a=10
    render() {
    return(
        <div>
            <h2></h2>
            </div>

    )
}
}
//obj=new ClassCompEG()
//console.log(obj.a)
export default ClassCompEg;